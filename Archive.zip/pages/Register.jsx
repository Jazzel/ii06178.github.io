import React from "react";

import Reg from "../components/reg";


function Register(){
    // loading = () => <div className="animated fadeIn pt-1 text-center">Loading...</div> 
   
        return(
            <div>
                <body class="bg-gradient-primary">
                <Reg/>
                </body>
               
               
            </div>
           
           

        )
}

export default Register;