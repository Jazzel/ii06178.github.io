import React from "react";
import Forgot from "../components/forgot";



function ForgotPassword(){
    // loading = () => <div className="animated fadeIn pt-1 text-center">Loading...</div> 
   
        return(
            <div>
                <body class="bg-gradient-primary">
               <Forgot/>
               </body>
            </div>
           
           

        )
}

export default ForgotPassword;